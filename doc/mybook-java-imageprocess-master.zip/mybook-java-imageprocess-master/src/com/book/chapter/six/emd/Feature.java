package com.book.chapter.six.emd;


public interface Feature {
    public double groundDist(Feature f);
}