package com.book.chapter.six;

public interface ViewCallBack {
	
	public void mooveLine(double position);

}
