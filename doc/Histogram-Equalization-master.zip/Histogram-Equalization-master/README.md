Histogram-Equalization
======================

A Distributed Computing Project to implement sockets. 
